#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n=1993;
	cout<<ceil(log10(n))<<endl; 
	double w=ceil(1993*log10(2)); 
	cout<<w<<endl;
	cout<<pow(2.0,1993)<<endl;
	return 0;
}
